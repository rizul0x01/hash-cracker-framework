import unittest
import bcrypt
from hash_cracker.core.detector import HashDetector
from hash_cracker.cracking.bcrypt_cracker import crack_bcrypt
from hash_cracker.utils.errors import WordlistExhaustedError

class TestBcrypt(unittest.TestCase):
    def test_bcrypt_detection(self):
        test_hash = bcrypt.hashpw(b"password", bcrypt.gensalt()).decode("utf-8")
        self.assertEqual(HashDetector().detect(test_hash), "bcrypt")

    def test_bcrypt_cracking(self):
        password = "password"
        hashed_password = bcrypt.hashpw(password.encode(), bcrypt.gensalt()).decode("utf-8")

        wordlist = ["wrong", "password", "test"]
        cracked_password = crack_bcrypt(hashed_password, wordlist)
        self.assertEqual(cracked_password, password)

        with self.assertRaises(WordlistExhaustedError):
            crack_bcrypt(hashed_password, ["wrong", "incorrect"])

if __name__ == '__main__':
    unittest.main()


