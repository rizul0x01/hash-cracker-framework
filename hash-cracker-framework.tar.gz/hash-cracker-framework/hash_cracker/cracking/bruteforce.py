"""
Bruteforce attack implementation
"""

from typing import Callable, Optional
from itertools import product
from ..utils.performance import PerformanceMetrics

class BruteforceCracker:
    """Bruteforce password cracker"""
    
    def __init__(self, charset: str, min_len: int, max_len: int, verify_func: Callable[[str, str], bool]):
        """
        Initialize bruteforce cracker
        
        Args:
            charset: Character set to use for bruteforce
            min_len: Minimum password length
            max_len: Maximum password length
            verify_func: Function to verify password against hash
        """
        self.charset = charset
        self.min_len = min_len
        self.max_len = max_len
        self.verify_func = verify_func
        self.metrics = PerformanceMetrics()

    def crack(self, target_hash: str, progress_callback: Optional[Callable] = None) -> Optional[str]:
        """
        Crack hash using bruteforce attack
        
        Args:
            target_hash: Hash to crack
            progress_callback: Optional callback for progress updates
            
        Returns:
            Cracked password or None if not found
        """
        self.metrics.start()
        
        try:
            for length in range(self.min_len, self.max_len + 1):
                for attempt_tuple in product(self.charset, repeat=length):
                    self.metrics.increment_attempts()
                    
                    if progress_callback:
                        progress_callback()
                    
                    attempt = "".join(attempt_tuple)
                    
                    try:
                        if self.verify_func(attempt, target_hash):
                            self.metrics.stop()
                            return attempt
                    except Exception:
                        continue
            
            self.metrics.stop()
            return None
            
        except KeyboardInterrupt:
            self.metrics.stop()
            raise
        except Exception as e:
            self.metrics.stop()
            return None

    def estimate_total_combinations(self) -> int:
        """
        Estimate total number of combinations
        
        Returns:
            Total combinations to try
        """
        total = 0
        for length in range(self.min_len, self.max_len + 1):
            total += len(self.charset) ** length
        return total

    def get_metrics(self) -> PerformanceMetrics:
        """Get performance metrics"""
        return self.metrics
