
from typing import Optional
from hashes.base import AbstractHashCracker
from cracking.dictionary import DictionaryCracker
from argon2 import PasswordHasher
from argon2.exceptions import VerifyMismatchError

class ARGON2Cracker(AbstractHashCracker):
    def crack(self, target_hash: str) -> Optional[str]:
        wordlist = ["password", "123456", "admin", "qwerty", "hello"]
        
        dictionary_cracker = DictionaryCracker(wordlist, self._verify_password)
        cracked_password = dictionary_cracker.crack(target_hash)
        return cracked_password

    def _verify_password(self, password: str, target_hash: str) -> bool:
        ph = PasswordHasher()
        try:
            ph.verify(target_hash, password)
            return True
        except VerifyMismatchError:
            return False
        except Exception as e:
            print(f"Error verifying Argon2 hash: {e}")
            return False


