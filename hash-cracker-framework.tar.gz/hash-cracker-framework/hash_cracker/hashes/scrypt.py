"""
Scrypt hash implementation
"""

import hashlib
import base64
from .base import HashBase

class ScryptHash(HashBase):
    """Scrypt hash implementation"""
    
    def __init__(self, N: int = 16384, r: int = 8, p: int = 1):
        super().__init__()
        self.N = N
        self.r = r
        self.p = p
    
    def compute(self, data: str, **kwargs) -> str:
        """
        Compute Scrypt hash
        
        Args:
            data: Data to hash
            **kwargs: Additional parameters (salt, N, r, p)
            
        Returns:
            Scrypt hash string
        """
        import os
        salt = kwargs.get('salt', os.urandom(16))
        N = kwargs.get('N', self.N)
        r = kwargs.get('r', self.r)
        p = kwargs.get('p', self.p)
        
        if isinstance(salt, str):
            salt = salt.encode('utf-8')
        
        hash_bytes = hashlib.scrypt(data.encode('utf-8'), salt=salt, n=N, r=r, p=p, dklen=32)
        
        # Return in standard format
        salt_b64 = base64.b64encode(salt).decode('utf-8')
        hash_b64 = base64.b64encode(hash_bytes).decode('utf-8')
        
        return f"$s0${N}${r}${p}${salt_b64}${hash_b64}"
    
    def verify(self, password: str, hash_str: str) -> bool:
        """
        Verify password against Scrypt hash
        
        Args:
            password: Password to verify
            hash_str: Scrypt hash string
            
        Returns:
            True if password matches hash
        """
        try:
            if hash_str.startswith('$s0$'):
                parts = hash_str.split('$')
                if len(parts) >= 7:
                    N = int(parts[2])
                    r = int(parts[3])
                    p = int(parts[4])
                    salt = base64.b64decode(parts[5])
                    expected_hash = base64.b64decode(parts[6])
                    
                    computed_hash = hashlib.scrypt(password.encode('utf-8'), salt=salt, n=N, r=r, p=p, dklen=32)
                    return computed_hash == expected_hash
            
            return False
        except Exception:
            return False
    
    def get_info(self) -> dict:
        """Get Scrypt hash information"""
        info = super().get_info()
        info.update({
            'algorithm': 'Scrypt',
            'N': self.N,
            'r': self.r,
            'p': self.p,
            'description': 'Scrypt key derivation function'
        })
        return info
