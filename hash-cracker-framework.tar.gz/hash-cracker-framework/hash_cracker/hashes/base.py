"""
Base hash implementation
"""

from abc import ABC, abstractmethod
from typing import Optional, Any, Dict

class HashBase(ABC):
    """Base class for hash implementations"""
    
    def __init__(self):
        self.name = self.__class__.__name__
    
    @abstractmethod
    def compute(self, data: str, **kwargs) -> str:
        """
        Compute hash of given data
        
        Args:
            data: Data to hash
            **kwargs: Additional parameters
            
        Returns:
            Hash string
        """
        pass
    
    @abstractmethod
    def verify(self, password: str, hash_str: str) -> bool:
        """
        Verify password against hash
        
        Args:
            password: Password to verify
            hash_str: Hash string to verify against
            
        Returns:
            True if password matches hash
        """
        pass
    
    def get_info(self) -> Dict[str, Any]:
        """
        Get information about this hash type
        
        Returns:
            Dictionary with hash information
        """
        return {
            'name': self.name,
            'type': self.__class__.__name__,
            'module': self.__module__
        }
    
    def __str__(self) -> str:
        return self.name
    
    def __repr__(self) -> str:
        return f"{self.__class__.__name__}()"
