"""
SSHA (Salted SHA-1) hash cracking implementation
"""

import base64
import hashlib
from typing import List, Optional, Callable
from ..utils.errors import WordlistExhaustedError, SaltMismatchError
from ..utils.performance import PerformanceMetrics

def crack_ssha(hash_str: str, wordlist: List[str], 
               progress_callback: Optional[Callable] = None) -> Optional[str]:
    """
    Crack SSHA hash using dictionary attack
    
    Args:
        hash_str: SSHA hash string
        wordlist: List of passwords to try
        progress_callback: Optional callback for progress updates
        
    Returns:
        Cracked password or None if not found
    """
    metrics = PerformanceMetrics()
    metrics.start()
    
    try:
        # Parse SSHA format
        if hash_str.startswith('{SSHA}'):
            hash_str = hash_str[6:]  # Remove {SSHA} prefix
        
        decoded = base64.b64decode(hash_str)
        
        # SHA-1 produces 20-byte hash, rest is salt
        if len(decoded) < 20:
            raise SaltMismatchError("Invalid SSHA hash format")
        
        expected_hash = decoded[:20]
        salt = decoded[20:]
        
        for word in wordlist:
            metrics.increment_attempts()
            
            if progress_callback:
                progress_callback()
            
            try:
                derived = hashlib.sha1(word.encode('utf-8') + salt).digest()
                if derived == expected_hash:
                    metrics.stop()
                    return word
            except Exception:
                continue
        
        metrics.stop()
        return None
        
    except Exception as e:
        metrics.stop()
        raise WordlistExhaustedError(f"SSHA cracking failed: {e}")

def verify_ssha(password: str, hash_str: str) -> bool:
    """
    Verify password against SSHA hash
    
    Args:
        password: Password to verify
        hash_str: SSHA hash string
        
    Returns:
        True if password matches hash
    """
    try:
        if hash_str.startswith('{SSHA}'):
            hash_str = hash_str[6:]
        
        decoded = base64.b64decode(hash_str)
        expected_hash = decoded[:20]
        salt = decoded[20:]
        
        derived = hashlib.sha1(password.encode('utf-8') + salt).digest()
        return derived == expected_hash
    except Exception:
        return False
