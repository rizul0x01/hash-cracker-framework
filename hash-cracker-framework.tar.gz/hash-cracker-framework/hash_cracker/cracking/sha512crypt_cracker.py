"""
SHA512 crypt hash cracking implementation
"""

from passlib.hash import sha512_crypt
from typing import List, Optional, Callable
from ..utils.errors import WordlistExhaustedError
from ..utils.performance import PerformanceMetrics

def crack_sha512crypt(hash_str: str, wordlist: List[str], 
                     progress_callback: Optional[Callable] = None) -> Optional[str]:
    """
    Crack SHA512 crypt hash using dictionary attack
    
    Args:
        hash_str: SHA512 crypt hash string
        wordlist: List of passwords to try
        progress_callback: Optional callback for progress updates
        
    Returns:
        Cracked password or None if not found
    """
    metrics = PerformanceMetrics()
    metrics.start()
    
    try:
        for word in wordlist:
            metrics.increment_attempts()
            
            if progress_callback:
                progress_callback()
            
            try:
                if sha512_crypt.verify(word, hash_str):
                    metrics.stop()
                    return word
            except Exception:
                continue
        
        metrics.stop()
        return None
        
    except Exception as e:
        metrics.stop()
        raise WordlistExhaustedError(f"SHA512 crypt cracking failed: {e}")

def verify_sha512crypt(password: str, hash_str: str) -> bool:
    """
    Verify password against SHA512 crypt hash
    
    Args:
        password: Password to verify
        hash_str: SHA512 crypt hash string
        
    Returns:
        True if password matches hash
    """
    try:
        return sha512_crypt.verify(password, hash_str)
    except Exception:
        return False
