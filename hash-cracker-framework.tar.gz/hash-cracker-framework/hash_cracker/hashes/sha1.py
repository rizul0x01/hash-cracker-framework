"""
SHA1 hash implementation
"""

import hashlib
from .base import HashBase

class SHA1Hash(HashBase):
    """SHA1 hash implementation"""
    
    def compute(self, data: str, **kwargs) -> str:
        """
        Compute SHA1 hash
        
        Args:
            data: Data to hash
            **kwargs: Additional parameters
            
        Returns:
            SHA1 hash string
        """
        return hashlib.sha1(data.encode('utf-8')).hexdigest()
    
    def verify(self, password: str, hash_str: str) -> bool:
        """
        Verify password against SHA1 hash
        
        Args:
            password: Password to verify
            hash_str: SHA1 hash string
            
        Returns:
            True if password matches hash
        """
        try:
            computed = self.compute(password)
            return computed.lower() == hash_str.lower()
        except Exception:
            return False
    
    def get_info(self) -> dict:
        """Get SHA1 hash information"""
        info = super().get_info()
        info.update({
            'algorithm': 'SHA1',
            'length': 40,
            'description': 'SHA-1 cryptographic hash function'
        })
        return info
