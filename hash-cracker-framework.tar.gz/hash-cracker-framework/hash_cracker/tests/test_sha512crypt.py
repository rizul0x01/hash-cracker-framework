import unittest
from hash_cracker.core.detector import HashDetector
from hash_cracker.cracking.sha512crypt_cracker import crack_sha512crypt
from hash_cracker.utils.errors import WordlistExhaustedError
import crypt

class TestSHA512Crypt(unittest.TestCase):
    def test_sha512crypt_detection(self):
        test_hash = "$6$rounds=5000$saltsalt$AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA="
        print(f"Testing SHA512Crypt detection with hash: {test_hash}")
        self.assertEqual(HashDetector().detect(test_hash), "SHA512Crypt")

    def test_sha512crypt_cracking(self):
        password = "password"
        # Generate a SHA512Crypt hash for testing
        salt = "$6$rounds=5000$saltsalt"
        test_hash = crypt.crypt(password, salt)

        wordlist = ["wrong", "password", "test"]
        cracked_password = crack_sha512crypt(test_hash, wordlist)
        self.assertEqual(cracked_password, password)

        with self.assertRaises(WordlistExhaustedError):
            crack_sha512crypt(test_hash, ["wrong", "incorrect"])

if __name__ == '__main__':
    unittest.main()


