import unittest
import hashlib
import base64
from hash_cracker.core.detector import validate_pbkdf2_match, HashDetector
from hash_cracker.cracking.pbkdf2_sha256 import crack_pbkdf2_sha256

class TestPBKDF2(unittest.TestCase):
    def test_pbkdf2_detection(self):
        # Example PBKDF2-SHA256 hash
        test_hash = "$pbkdf2-sha256$10000$c2FsdHNlY3JldA==$AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=" # 32 bytes base64 encoded
        self.assertEqual(HashDetector().detect(test_hash), "PBKDF2")

    def test_pbkdf2_validation(self):
        # Valid PBKDF2-SHA256 hash
        valid_hash = "$pbkdf2-sha256$10000$c2FsdHNlY3JldA==$AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=" # 32 bytes base64 encoded
        self.assertTrue(validate_pbkdf2_match(valid_hash))

        # Invalid PBKDF2-SHA256 hash (incorrect hash_value length)
        invalid_hash = "$pbkdf2-sha256$10000$c2FsdHNlY3JldA==$dGVzdGhhc2h2YWx1ZTE="
        self.assertFalse(validate_pbkdf2_match(invalid_hash))

    def test_pbkdf2_cracking(self):
        password = "password"
        salt = b"saltsalt"
        iterations = 10000
        # Simulate a hash creation for testing
        derived_key = hashlib.pbkdf2_hmac("sha256", password.encode(), salt, iterations)
        test_hash_value = derived_key

        wordlist = ["wrong", "password", "test"]
        cracked_password = crack_pbkdf2_sha256(test_hash_value, salt, iterations, wordlist)
        self.assertEqual(cracked_password, password)

        # Test with a wordlist that doesn't contain the password
        wordlist_fail = ["wrong", "incorrect"]
        cracked_password_fail = crack_pbkdf2_sha256(test_hash_value, salt, iterations, wordlist_fail)
        self.assertIsNone(cracked_password_fail)

if __name__ == '__main__':
    unittest.main()


