"""
bcrypt hash implementation
"""

import bcrypt
from .base import HashBase

class BcryptHash(HashBase):
    """bcrypt hash implementation"""
    
    def __init__(self, rounds: int = 12):
        super().__init__()
        self.rounds = rounds
    
    def compute(self, data: str, **kwargs) -> str:
        """
        Compute bcrypt hash
        
        Args:
            data: Data to hash
            **kwargs: Additional parameters (rounds)
            
        Returns:
            bcrypt hash string
        """
        rounds = kwargs.get('rounds', self.rounds)
        salt = bcrypt.gensalt(rounds=rounds)
        hash_bytes = bcrypt.hashpw(data.encode('utf-8'), salt)
        return hash_bytes.decode('utf-8')
    
    def verify(self, password: str, hash_str: str) -> bool:
        """
        Verify password against bcrypt hash
        
        Args:
            password: Password to verify
            hash_str: bcrypt hash string
            
        Returns:
            True if password matches hash
        """
        try:
            return bcrypt.checkpw(password.encode('utf-8'), hash_str.encode('utf-8'))
        except Exception:
            return False
    
    def get_info(self) -> dict:
        """Get bcrypt hash information"""
        info = super().get_info()
        info.update({
            'algorithm': 'bcrypt',
            'rounds': self.rounds,
            'description': 'bcrypt adaptive hash function'
        })
        return info
