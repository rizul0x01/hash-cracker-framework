"""
MD5 hash implementation
"""

import hashlib
from .base import HashBase

class MD5Hash(HashBase):
    """MD5 hash implementation"""
    
    def compute(self, data: str, **kwargs) -> str:
        """
        Compute MD5 hash
        
        Args:
            data: Data to hash
            **kwargs: Additional parameters
            
        Returns:
            MD5 hash string
        """
        return hashlib.md5(data.encode('utf-8')).hexdigest()
    
    def verify(self, password: str, hash_str: str) -> bool:
        """
        Verify password against MD5 hash
        
        Args:
            password: Password to verify
            hash_str: MD5 hash string
            
        Returns:
            True if password matches hash
        """
        try:
            computed = self.compute(password)
            return computed.lower() == hash_str.lower()
        except Exception:
            return False
    
    def get_info(self) -> dict:
        """Get MD5 hash information"""
        info = super().get_info()
        info.update({
            'algorithm': 'MD5',
            'length': 32,
            'description': 'MD5 cryptographic hash function'
        })
        return info
