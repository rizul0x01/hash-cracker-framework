from setuptools import setup, find_packages

setup(
    name="hash_cracker",
    version="1.0.0",
    description="Advanced Hash Cracking Framework",
    author="rizul0x01",
    author_email="rizul0x01@gmail.com",
    packages=find_packages(),
    install_requires=[
        "bcrypt>=4.0.0",
        "rich>=13.0.0",
        "passlib>=1.7.4",
        "cryptography>=3.4.8",
        "scrypt>=0.8.20",
    ],
    python_requires=">=3.8",
    entry_points={
        "console_scripts": [
            "hash-cracker=main:main",
        ],
    },
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
    ],
)

print("\nPackage setup complete.")
print("Author: rizul0x01")
print("Email: rizul0x01@gmail.com.com")
print("https://github.com/rizul0x01")
