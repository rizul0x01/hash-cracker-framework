"""
bcrypt hash cracking implementation
"""

import bcrypt
from typing import List, Optional, Callable
from ..utils.errors import WordlistExhaustedError
from ..utils.performance import PerformanceMetrics

def crack_bcrypt(hash_str: str, wordlist: List[str], 
                 progress_callback: Optional[Callable] = None) -> Optional[str]:
    """
    Crack bcrypt hash using dictionary attack
    
    Args:
        hash_str: bcrypt hash string
        wordlist: List of passwords to try
        progress_callback: Optional callback for progress updates
        
    Returns:
        Cracked password or None if not found
    """
    metrics = PerformanceMetrics()
    metrics.start()
    
    try:
        hash_bytes = hash_str.encode('utf-8')
        
        for word in wordlist:
            metrics.increment_attempts()
            
            if progress_callback:
                progress_callback()
            
            try:
                word_bytes = word.encode('utf-8')
                if bcrypt.checkpw(word_bytes, hash_bytes):
                    metrics.stop()
                    return word
            except Exception:
                # Skip invalid passwords
                continue
        
        metrics.stop()
        return None
        
    except Exception as e:
        metrics.stop()
        raise WordlistExhaustedError(f"bcrypt cracking failed: {e}")

def verify_bcrypt(password: str, hash_str: str) -> bool:
    """
    Verify password against bcrypt hash
    
    Args:
        password: Password to verify
        hash_str: bcrypt hash string
        
    Returns:
        True if password matches hash
    """
    try:
        return bcrypt.checkpw(password.encode('utf-8'), hash_str.encode('utf-8'))
    except Exception:
        return False
