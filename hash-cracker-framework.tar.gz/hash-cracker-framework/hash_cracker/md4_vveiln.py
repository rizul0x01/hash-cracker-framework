
import struct

WORD_MASK = (1 << 32) - 1
BYTES_IN_WORD = 4
BITS_IN_BYTE = 8
BITS_IN_WORD = BITS_IN_BYTE * BYTES_IN_WORD

def left_circular_shift(x, s):
    return ((x << s) | (x >> (BITS_IN_WORD - s))) & WORD_MASK

def chunk(s, size):
    return [s[i : i + size] for i in range(0, len(s), size)]

def mul(x, y):
    return (x & y) & WORD_MASK

def neg(x):
    return (x ^ WORD_MASK) & WORD_MASK

def F(x, y, z):
    """acts as a conditional if X then Y else Z"""
    return mul(x, y) | mul(neg(x), z)

def G(x, y, z):
    """acts as a majority function"""
    return mul(x, y) | mul(x, z) | mul(y, z)

def H(x, y, z):
    return (x ^ y ^ z) & WORD_MASK


class MD4(object):
    NUMBER_OF_ROUNDS = 3
    BLOCK_SIZE = 64
    ROUND_CONSTANT = {
        0: 0x00000000,
        1: 0x5a827999,
        2: 0x6ed9eba1
    }
    ROUND_FUNCTION = {
        0: F,
        1: G,
        2: H
    }
    ROUND_PARAMS = {
        0: (
            (0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15),
            (3, 7, 11, 19) * 4
        ),
        1: (
            (0, 4, 8, 12, 1, 5, 9, 13, 2, 6, 10, 14, 3, 7, 11, 15),
            (3, 5, 9, 13) * 4
        ),
        2: (
            (0, 8, 4, 12, 2, 10, 6, 14, 1, 9, 5, 13, 3, 11, 7, 15),
            (3, 9, 11, 15) * 4
        )
    }

    def __init__(self):
        self._state = [0x67452301, 0xefcdab89, 0x98badcfe, 0x10325476]
        self.message = b''

    def update(self, message):
        self.message += bytearray(message, 'utf-8') if isinstance(message, str) else message

    def digest(self):
        message = self.message
        ml = len(message) * 8
        message += b'\x80'
        message += b'\x00' * (-(len(message) + 8) % 64)
        message += struct.pack('<Q', ml)

        for ch in chunk(message, self.BLOCK_SIZE):
            X = list(struct.unpack('<16I', ch))
            A, B, C, D = self._state

            for i in range(self.NUMBER_OF_ROUNDS):
                func = self.ROUND_FUNCTION[i]
                const = self.ROUND_CONSTANT[i]
                order, shifts = self.ROUND_PARAMS[i]

                for j in range(16):
                    k = order[j]
                    s = shifts[j]

                    if i == 0:
                        t = (A + func(B, C, D) + X[k]) & WORD_MASK
                    else:
                        t = (A + func(B, C, D) + X[k] + const) & WORD_MASK

                    A = D
                    D = C
                    C = B
                    B = left_circular_shift(t, s)

            self._state = [
                (self._state[0] + A) & WORD_MASK,
                (self._state[1] + B) & WORD_MASK,
                (self._state[2] + C) & WORD_MASK,
                (self._state[3] + D) & WORD_MASK
            ]

        return b''.join(struct.pack('<I', x) for x in self._state)

    def hexdigest(self):
        return self.digest().hex()


if __name__ == '__main__':
    import sys

    if len(sys.argv) > 1:
        message = sys.argv[1]
    else:
        message = 'The quick brown fox jumps over the lazy dog.'

    md4 = MD4()
    md4.update(message)
    print(md4.hexdigest())


