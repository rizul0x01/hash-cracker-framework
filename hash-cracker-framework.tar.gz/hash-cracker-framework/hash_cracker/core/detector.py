"""
Hash type detection module
"""

import re
import base64
from typing import Optional, Dict, List
from ..utils.errors import HashDetectionError

class HashDetector:
    """Detects hash types based on format patterns"""
    
    def __init__(self):
        self.patterns = self._initialize_patterns()
    
    def _initialize_patterns(self) -> Dict[str, List[Dict]]:
        """Initialize hash detection patterns"""
        return {
            'bcrypt': [
                {
                    'pattern': r'^\$2[axyb]\$[0-9]{2}\$[A-Za-z0-9\.\/]{53}$',
                    'description': 'bcrypt hash'
                }
            ],
            'md5': [
                {
                    'pattern': r'^[a-fA-F0-9]{32}$',
                    'description': 'MD5 hash'
                }
            ],
            'sha1': [
                {
                    'pattern': r'^[a-fA-F0-9]{40}$',
                    'description': 'SHA1 hash'
                }
            ],
            'sha256': [
                {
                    'pattern': r'^[a-fA-F0-9]{64}$',
                    'description': 'SHA256 hash'
                }
            ],
            'sha512': [
                {
                    'pattern': r'^[a-fA-F0-9]{128}$',
                    'description': 'SHA512 hash'
                }
            ],
            'ntlm': [
                {
                    'pattern': r'^[a-fA-F0-9]{32}$',
                    'description': 'NTLM hash'
                }
            ],
            'lm': [
                {
                    'pattern': r'^[a-fA-F0-9]{32}$',
                    'description': 'LM hash'
                }
            ],
            'sha512crypt': [
                {
                    'pattern': r'^\$6\$[a-zA-Z0-9\.\/]{0,16}\$[a-zA-Z0-9\.\/]{86}$',
                    'description': 'SHA512 crypt'
                }
            ],
            'sha256crypt': [
                {
                    'pattern': r'^\$5\$[a-zA-Z0-9\.\/]{0,16}\$[a-zA-Z0-9\.\/]{43}$',
                    'description': 'SHA256 crypt'
                }
            ],
            'md5crypt': [
                {
                    'pattern': r'^\$1\$[a-zA-Z0-9\.\/]{0,8}\$[a-zA-Z0-9\.\/]{22}$',
                    'description': 'MD5 crypt'
                }
            ],
            'pbkdf2': [
                {
                    'pattern': r'^\$pbkdf2-sha256\$[0-9]+\$[a-zA-Z0-9\.\/\+]+\$[a-zA-Z0-9\.\/\+]+$',
                    'description': 'PBKDF2 SHA256'
                }
            ],
            'scrypt': [
                {
                    'pattern': r'^\$s0\$[0-9]+\$[a-zA-Z0-9\.\/\+]+\$[a-zA-Z0-9\.\/\+]+$',
                    'description': 'Scrypt'
                }
            ],
            'argon2': [
                {
                    'pattern': r'^\$argon2[id]\$v=[0-9]+\$m=[0-9]+,t=[0-9]+,p=[0-9]+\$[a-zA-Z0-9\.\/\+]+\$[a-zA-Z0-9\.\/\+]+$',
                    'description': 'Argon2'
                }
            ],
            'ssha': [
                {
                    'pattern': r'^\{SSHA\}[a-zA-Z0-9\.\/\+]+={0,2}$',
                    'description': 'SSHA hash'
                }
            ],
            'cisco_type9': [
                {
                    'pattern': r'^\$9\$[a-zA-Z0-9\.\/\+]+$',
                    'description': 'Cisco Type 9 (Scrypt)'
                }
            ],
            'cisco_type8': [
                {
                    'pattern': r'^\$8\$[a-zA-Z0-9\.\/\+]+$',
                    'description': 'Cisco Type 8 (PBKDF2)'
                }
            ]
        }
    
    def detect(self, hash_str: str) -> Optional[str]:
        """
        Detect hash type from hash string
        
        Args:
            hash_str: Hash string to analyze
            
        Returns:
            Detected hash type or None
        """
        if not hash_str:
            return None
            
        hash_str = hash_str.strip()
        
        # Check each pattern
        for hash_type, patterns in self.patterns.items():
            for pattern_info in patterns:
                if re.match(pattern_info['pattern'], hash_str):
                    return hash_type
        
        # Additional heuristics for ambiguous cases
        return self._advanced_detection(hash_str)
    
    def _advanced_detection(self, hash_str: str) -> Optional[str]:
        """
        Advanced detection for ambiguous hash types
        
        Args:
            hash_str: Hash string to analyze
            
        Returns:
            Detected hash type or None
        """
        # Handle 32-character hex strings (could be MD5, NTLM, or LM)
        if re.match(r'^[a-fA-F0-9]{32}$', hash_str):
            # Check for common LM patterns
            if hash_str.upper().endswith('AAD3B435B51404EE'):
                return 'lm'
            # For now, default to MD5 for 32-char hex
            return 'md5'
        
        # Handle base64-encoded hashes
        if self._is_base64(hash_str):
            try:
                decoded = base64.b64decode(hash_str)
                if len(decoded) == 16:
                    return 'md5_base64'
                elif len(decoded) == 20:
                    return 'sha1_base64'
                elif len(decoded) == 32:
                    return 'sha256_base64'
                elif len(decoded) == 64:
                    return 'sha512_base64'
            except Exception:
                pass
        
        return None
    
    def _is_base64(self, s: str) -> bool:
        """Check if string is valid base64"""
        try:
            return base64.b64encode(base64.b64decode(s)).decode() == s
        except Exception:
            return False
    
    def get_hash_info(self, hash_str: str) -> Dict:
        """
        Get detailed information about a hash
        
        Args:
            hash_str: Hash string to analyze
            
        Returns:
            Dictionary with hash information
        """
        hash_type = self.detect(hash_str)
        
        info = {
            'hash': hash_str,
            'type': hash_type,
            'length': len(hash_str),
            'charset': self._analyze_charset(hash_str)
        }
        
        if hash_type and hash_type in self.patterns:
            info['description'] = self.patterns[hash_type][0]['description']
        
        return info
    
    def _analyze_charset(self, hash_str: str) -> str:
        """Analyze character set used in hash"""
        if re.match(r'^[a-f0-9]+$', hash_str):
            return 'hex_lower'
        elif re.match(r'^[A-F0-9]+$', hash_str):
            return 'hex_upper'
        elif re.match(r'^[a-fA-F0-9]+$', hash_str):
            return 'hex_mixed'
        elif re.match(r'^[a-zA-Z0-9\.\/\+]+={0,2}$', hash_str):
            return 'base64'
        else:
            return 'mixed'
