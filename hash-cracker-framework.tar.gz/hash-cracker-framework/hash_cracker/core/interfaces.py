"""
Interface definitions for hash cracking components
"""

from abc import ABC, abstractmethod
from typing import Optional, List, Dict, Any, Callable

class CrackerInterface(ABC):
    """Base interface for hash crackers"""
    
    @abstractmethod
    def crack(self, hash_str: str, wordlist: List[str], 
              progress_callback: Optional[Callable] = None) -> Optional[str]:
        """
        Crack the given hash using the provided wordlist
        
        Args:
            hash_str: Hash string to crack
            wordlist: List of words to try
            progress_callback: Optional callback for progress updates
            
        Returns:
            Cracked password or None if not found
        """
        pass
    
    @abstractmethod
    def verify(self, password: str, hash_str: str) -> bool:
        """
        Verify if password matches the hash
        
        Args:
            password: Password to verify
            hash_str: Hash string to verify against
            
        Returns:
            True if password matches hash, False otherwise
        """
        pass

class HashInterface(ABC):
    """Base interface for hash implementations"""
    
    @abstractmethod
    def compute(self, data: str) -> str:
        """
        Compute hash of given data
        
        Args:
            data: Data to hash
            
        Returns:
            Hash string
        """
        pass
    
    @abstractmethod
    def verify(self, password: str, hash_str: str) -> bool:
        """
        Verify password against hash
        
        Args:
            password: Password to verify
            hash_str: Hash string to verify against
            
        Returns:
            True if password matches hash
        """
        pass

class DetectorInterface(ABC):
    """Interface for hash detection"""
    
    @abstractmethod
    def detect(self, hash_str: str) -> Optional[str]:
        """
        Detect hash type from hash string
        
        Args:
            hash_str: Hash string to analyze
            
        Returns:
            Detected hash type or None
        """
        pass

class ReporterInterface(ABC):
    """Interface for reporting results"""
    
    @abstractmethod
    def report_detection_start(self):
        """Report start of hash detection"""
        pass
    
    @abstractmethod
    def report_detection_result(self, hash_type: str):
        """Report hash detection result"""
        pass
    
    @abstractmethod
    def report_cracking_start(self, hash_type: str):
        """Report start of cracking process"""
        pass
    
    @abstractmethod
    def report_cracking_result(self, hash_str: str, hash_type: str, result: Optional[str]):
        """Report cracking result"""
        pass
    
    @abstractmethod
    def report_error(self, error: str):
        """Report error"""
        pass
