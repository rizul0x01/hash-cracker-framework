"""
Hash Cracker Framework
Advanced hash cracking toolkit with support for multiple hash types
"""

__version__ = "1.0.0"
__author__ = "rizulo0x01"

from .core.engine import CrackEngine
from .core.detector import HashDetector
from .core.reporter import Reporter

__all__ = ['CrackEngine', 'HashDetector', 'Reporter']
