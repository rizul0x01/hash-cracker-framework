"""
NTLM hash implementation
"""

import hashlib
from .base import HashBase

class NTLMHash(HashBase):
    """NTLM hash implementation"""
    
    def compute(self, data: str, **kwargs) -> str:
        """
        Compute NTLM hash
        
        Args:
            data: Data to hash
            **kwargs: Additional parameters
            
        Returns:
            NTLM hash string
        """
        # NTLM uses UTF-16LE encoding
        return hashlib.new('md4', data.encode('utf-16le')).hexdigest()
    
    def verify(self, password: str, hash_str: str) -> bool:
        """
        Verify password against NTLM hash
        
        Args:
            password: Password to verify
            hash_str: NTLM hash string
            
        Returns:
            True if password matches hash
        """
        try:
            computed = self.compute(password)
            return computed.lower() == hash_str.lower()
        except Exception:
            return False
    
    def get_info(self) -> dict:
        """Get NTLM hash information"""
        info = super().get_info()
        info.update({
            'algorithm': 'NTLM',
            'length': 32,
            'description': 'NTLM hash (Windows)'
        })
        return info
