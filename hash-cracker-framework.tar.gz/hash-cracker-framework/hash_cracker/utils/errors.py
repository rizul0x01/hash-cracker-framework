"""
Custom exception classes for hash cracking
"""

class HashCrackerError(Exception):
    """Base exception for hash cracker errors"""
    pass

class UnsupportedHashTypeError(HashCrackerError):
    """Raised when hash type is not supported"""
    pass

class WordlistExhaustedError(HashCrackerError):
    """Raised when wordlist is exhausted without finding password"""
    pass

class SaltMismatchError(HashCrackerError):
    """Raised when salt extraction fails"""
    pass

class HashDetectionError(HashCrackerError):
    """Raised when hash detection fails"""
    pass

class InvalidHashFormatError(HashCrackerError):
    """Raised when hash format is invalid"""
    pass

class CrackingTimeoutError(HashCrackerError):
    """Raised when cracking times out"""
    pass

class InsufficientResourcesError(HashCrackerError):
    """Raised when system resources are insufficient"""
    pass

class ConfigurationError(HashCrackerError):
    """Raised when configuration is invalid"""
    pass
