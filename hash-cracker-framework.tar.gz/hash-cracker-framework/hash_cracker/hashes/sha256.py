"""
SHA256 hash implementation
"""

import hashlib
from .base import HashBase

class SHA256Hash(HashBase):
    """SHA256 hash implementation"""
    
    def compute(self, data: str, **kwargs) -> str:
        """
        Compute SHA256 hash
        
        Args:
            data: Data to hash
            **kwargs: Additional parameters
            
        Returns:
            SHA256 hash string
        """
        return hashlib.sha256(data.encode('utf-8')).hexdigest()
    
    def verify(self, password: str, hash_str: str) -> bool:
        """
        Verify password against SHA256 hash
        
        Args:
            password: Password to verify
            hash_str: SHA256 hash string
            
        Returns:
            True if password matches hash
        """
        try:
            computed = self.compute(password)
            return computed.lower() == hash_str.lower()
        except Exception:
            return False
    
    def get_info(self) -> dict:
        """Get SHA256 hash information"""
        info = super().get_info()
        info.update({
            'algorithm': 'SHA256',
            'length': 64,
            'description': 'SHA-256 cryptographic hash function'
        })
        return info
