"""
PBKDF2 hash implementation
"""

import hashlib
import base64
from .base import HashBase

class PBKDF2Hash(HashBase):
    """PBKDF2 hash implementation"""
    
    def __init__(self, iterations: int = 10000, salt_length: int = 16):
        super().__init__()
        self.iterations = iterations
        self.salt_length = salt_length
    
    def compute(self, data: str, **kwargs) -> str:
        """
        Compute PBKDF2 hash
        
        Args:
            data: Data to hash
            **kwargs: Additional parameters (salt, iterations)
            
        Returns:
            PBKDF2 hash string
        """
        import os
        salt = kwargs.get('salt', os.urandom(self.salt_length))
        iterations = kwargs.get('iterations', self.iterations)
        
        if isinstance(salt, str):
            salt = salt.encode('utf-8')
        
        hash_bytes = hashlib.pbkdf2_hmac('sha256', data.encode('utf-8'), salt, iterations)
        
        # Return in standard format
        salt_b64 = base64.b64encode(salt).decode('utf-8')
        hash_b64 = base64.b64encode(hash_bytes).decode('utf-8')
        
        return f"$pbkdf2-sha256${iterations}${salt_b64}${hash_b64}"
    
    def verify(self, password: str, hash_str: str) -> bool:
        """
        Verify password against PBKDF2 hash
        
        Args:
            password: Password to verify
            hash_str: PBKDF2 hash string
            
        Returns:
            True if password matches hash
        """
        try:
            if hash_str.startswith('$pbkdf2-sha256$'):
                parts = hash_str.split('$')
                if len(parts) >= 5:
                    iterations = int(parts[2])
                    salt = base64.b64decode(parts[3])
                    expected_hash = base64.b64decode(parts[4])
                    
                    computed_hash = hashlib.pbkdf2_hmac('sha256', password.encode('utf-8'), salt, iterations)
                    return computed_hash == expected_hash
            
            return False
        except Exception:
            return False
    
    def get_info(self) -> dict:
        """Get PBKDF2 hash information"""
        info = super().get_info()
        info.update({
            'algorithm': 'PBKDF2-SHA256',
            'iterations': self.iterations,
            'salt_length': self.salt_length,
            'description': 'PBKDF2 key derivation function'
        })
        return info
