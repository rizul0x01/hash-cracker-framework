"""
SSHA hash implementation
"""

import hashlib
import base64
from .base import HashBase

class SSHAHash(HashBase):
    """SSHA hash implementation"""
    
    def compute(self, data: str, **kwargs) -> str:
        """
        Compute SSHA hash
        
        Args:
            data: Data to hash
            **kwargs: Additional parameters (salt)
            
        Returns:
            SSHA hash string
        """
        import os
        salt = kwargs.get('salt', os.urandom(16))
        
        if isinstance(salt, str):
            salt = salt.encode('utf-8')
        
        hash_bytes = hashlib.sha1(data.encode('utf-8') + salt).digest()
        combined = hash_bytes + salt
        
        return '{SSHA}' + base64.b64encode(combined).decode('utf-8')
    
    def verify(self, password: str, hash_str: str) -> bool:
        """
        Verify password against SSHA hash
        
        Args:
            password: Password to verify
            hash_str: SSHA hash string
            
        Returns:
            True if password matches hash
        """
        try:
            if hash_str.startswith('{SSHA}'):
                hash_str = hash_str[6:]  # Remove {SSHA} prefix
            
            decoded = base64.b64decode(hash_str)
            
            # SHA-1 produces 20-byte hash, rest is salt
            if len(decoded) < 20:
                return False
            
            expected_hash = decoded[:20]
            salt = decoded[20:]
            
            computed_hash = hashlib.sha1(password.encode('utf-8') + salt).digest()
            return computed_hash == expected_hash
        except Exception:
            return False
    
    def get_info(self) -> dict:
        """Get SSHA hash information"""
        info = super().get_info()
        info.update({
            'algorithm': 'SSHA',
            'description': 'Salted SHA-1 hash'
        })
        return info
