"""
Cracking dispatcher that routes hash cracking to appropriate modules
"""

import os
from typing import Optional, List, Dict, Any, Callable
from rich.console import Console

from hash_cracker.core.detector import HashDetector
from hash_cracker.cracking.bcrypt_cracker import crack_bcrypt
from hash_cracker.cracking.pbkdf2_sha256 import crack_pbkdf2_sha256
from hash_cracker.cracking.scrypt_cisco9 import crack_scrypt_cisco9
from hash_cracker.cracking.sha512crypt_cracker import crack_sha512crypt
from hash_cracker.cracking.ssha_cracker import crack_ssha
from hash_cracker.cracking.lm import crack_lm
from hash_cracker.cracking.dictionary import DictionaryCracker
from hash_cracker.cracking.bruteforce import BruteforceCracker
from hash_cracker.hashes import *
from hash_cracker.utils.errors import UnsupportedHashTypeError

console = Console()

class CrackingDispatcher:
    """Dispatches hash cracking to appropriate modules"""
    
    def __init__(self):
        self.detector = HashDetector()
        self.crackers = self._initialize_crackers()
    
    def _initialize_crackers(self) -> Dict[str, Callable]:
        """Initialize hash-specific crackers"""
        return {
            'bcrypt': crack_bcrypt,
            'sha512crypt': crack_sha512crypt,
            'pbkdf2': crack_pbkdf2_sha256,
            'scrypt': crack_scrypt_cisco9,
            'cisco_type9': crack_scrypt_cisco9,
            'ssha': crack_ssha,
            'lm': crack_lm,
            'md5': self._crack_simple_hash,
            'sha1': self._crack_simple_hash,
            'sha256': self._crack_simple_hash,
            'sha512': self._crack_simple_hash,
            'ntlm': self._crack_simple_hash,
        }
    
    def dispatch(self, hash_str: str, wordlist_path: str, 
                 attack_options: Dict[str, Any] = None, 
                 progress_callback: Optional[Callable] = None) -> Optional[str]:
        """
        Dispatch hash cracking to appropriate module
        
        Args:
            hash_str: Hash string to crack
            wordlist_path: Path to the wordlist file
            attack_options: Attack configuration options
            progress_callback: Optional callback for progress updates
            
        Returns:
            Cracked password or None if not found
        """
        hash_type = self.detector.detect(hash_str)
        
        if not hash_type:
            raise UnsupportedHashTypeError("Could not detect hash type")
        
        wordlist = []
        if wordlist_path and os.path.exists(wordlist_path):
            with open(wordlist_path, 'r') as f:
                wordlist = [line.strip() for line in f]

        if attack_options is None:
            attack_options = {}

        # Try dictionary attack first if wordlist is provided
        if wordlist and not attack_options.get('bruteforce_only', False):
            console.print(f"[yellow]→[/yellow] Attempting dictionary attack...")
            result = self._try_dictionary_attack(hash_str, hash_type, wordlist, progress_callback)
            if result:
                return result
        
        # Try bruteforce if enabled
        if attack_options.get('bruteforce', False):
            console.print(f"[yellow]→[/yellow] Attempting bruteforce attack...")
            result = self._try_bruteforce_attack(hash_str, hash_type, attack_options, progress_callback)
            if result:
                return result
        
        return None
    
    def _try_dictionary_attack(self, hash_str: str, hash_type: str, 
                              wordlist: List[str], 
                              progress_callback: Optional[Callable] = None) -> Optional[str]:
        """Try dictionary attack"""
        try:
            if hash_type in self.crackers:
                # Use specific cracker
                cracker_func = self.crackers[hash_type]
                
                if hash_type == 'bcrypt':
                    return cracker_func(hash_str, wordlist)
                elif hash_type == 'sha512crypt':
                    return cracker_func(hash_str, wordlist)
                elif hash_type == 'pbkdf2':
                    # Extract salt and iterations from hash
                    salt, iterations = self._extract_pbkdf2_params(hash_str)
                    return cracker_func(hash_str, salt, iterations, wordlist)
                elif hash_type in ['scrypt', 'cisco_type9']:
                    # Extract scrypt parameters
                    salt, N, r, p = self._extract_scrypt_params(hash_str)
                    return cracker_func(hash_str, salt, N, r, p, wordlist)
                elif hash_type == 'ssha':
                    return cracker_func(hash_str, wordlist)
                elif hash_type == 'lm':
                    return cracker_func(hash_str, wordlist)
                else:
                    # Simple hash types (MD5, SHA1, etc.)
                    return cracker_func(hash_str, hash_type, wordlist)
            else:
                # Generic dictionary attack
                verify_func = self._get_verify_function(hash_type)
                cracker = DictionaryCracker(wordlist, verify_func)
                return cracker.crack(hash_str, progress_callback)
                
        except Exception as e:
            console.print(f"[red]Dictionary attack failed: {e}[/red]")
            return None
    
    def _try_bruteforce_attack(self, hash_str: str, hash_type: str, 
                              attack_options: Dict[str, Any],
                              progress_callback: Optional[Callable] = None) -> Optional[str]:
        """Try bruteforce attack"""
        try:
            charset = attack_options.get('charset', 'abcdefghijklmnopqrstuvwxyz0123456789')
            min_len = attack_options.get('min_len', 1)
            max_len = attack_options.get('max_len', 8)
            
            verify_func = self._get_verify_function(hash_type)
            cracker = BruteforceCracker(charset, min_len, max_len, verify_func)
            
            return cracker.crack(hash_str, progress_callback)
            
        except Exception as e:
            console.print(f"[red]Bruteforce attack failed: {e}[/red]")
            return None
    
    def _get_verify_function(self, hash_type: str) -> Callable:
        """Get verification function for hash type"""
        if hash_type == 'md5':
            from hash_cracker.hashes.md5 import MD5Hash
            return MD5Hash().verify
        elif hash_type == 'sha1':
            from hash_cracker.hashes.sha1 import SHA1Hash
            return SHA1Hash().verify
        elif hash_type == 'sha256':
            from hash_cracker.hashes.sha256 import SHA256Hash
            return SHA256Hash().verify
        elif hash_type == 'sha512':
            from hash_cracker.hashes.sha512 import SHA512Hash
            return SHA512Hash().verify
        elif hash_type == 'ntlm':
            from hash_cracker.hashes.ntlm import NTLMHash
            return NTLMHash().verify
        elif hash_type == 'lm':
            from hash_cracker.hashes.lm import LMHash
            return LMHash().verify
        else:
            raise UnsupportedHashTypeError(f"No verify function for hash type: {hash_type}")
    
    def _crack_simple_hash(self, hash_str: str, hash_type: str, 
                          wordlist: List[str], 
                          progress_callback: Optional[Callable] = None) -> Optional[str]:
        """Crack simple hash types using dictionary attack"""
        verify_func = self._get_verify_function(hash_type)
        cracker = DictionaryCracker(wordlist, verify_func)
        return cracker.crack(hash_str, progress_callback)
    
    def _extract_pbkdf2_params(self, hash_str: str) -> tuple:
        """Extract salt and iterations from PBKDF2 hash"""
        # Default values - in real implementation, parse from hash
        salt = b"saltsalt"
        iterations = 10000
        
        # TODO: Implement proper PBKDF2 hash parsing
        return salt, iterations
    
    def _extract_scrypt_params(self, hash_str: str) -> tuple:
        """Extract parameters from scrypt hash"""
        # Default values - in real implementation, parse from hash
        salt = b"saltsalt"
        N, r, p = 16384, 8, 1
        
        # TODO: Implement proper scrypt hash parsing
        return salt, N, r, p


