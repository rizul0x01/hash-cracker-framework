"""
Reporting module for hash cracking results
"""

import json
import csv
import time
from typing import Optional, Dict, Any
from rich.console import Console
from rich.table import Table
from rich.panel import Panel

from .interfaces import ReporterInterface

console = Console()

class Reporter(ReporterInterface):
    """Reports hash cracking results and progress"""
    
    def __init__(self):
        self.start_time = None
        self.results = []
    
    def report_detection_start(self):
        """Report start of hash detection"""
        console.print("[bold cyan]Starting hash detection...[/bold cyan]")
        self.start_time = time.time()
    
    def report_detection_result(self, hash_type: str):
        """Report hash detection result"""
        if hash_type:
            console.print(f"[green]✓[/green] Detected hash type: [bold yellow]{hash_type}[/bold yellow]")
        else:
            console.print("[red]✗[/red] Could not detect hash type")
    
    def report_cracking_start(self, hash_type: str):
        """Report start of cracking process"""
        console.print(f"[bold cyan]Starting {hash_type} cracking process...[/bold cyan]")
    
    def report_cracking_result(self, hash_str: str, hash_type: str, result: Optional[str]):
        """Report cracking result"""
        duration = time.time() - self.start_time if self.start_time else 0
        
        result_data = {
            'hash': hash_str,
            'type': hash_type,
            'result': result,
            'duration': duration,
            'timestamp': time.time()
        }
        
        self.results.append(result_data)
        
        if result:
            panel = Panel(
                f"[bold green]SUCCESS![/bold green]\n\n"
                f"Password: [bold red]{result}[/bold red]\n"
                f"Time: {duration:.2f} seconds",
                title="Password Found",
                border_style="green"
            )
            console.print(panel)
        else:
            panel = Panel(
                f"[bold red]FAILED[/bold red]\n\n"
                f"Password not found\n"
                f"Time: {duration:.2f} seconds",
                title="Cracking Failed",
                border_style="red"
            )
            console.print(panel)
    
    def report_error(self, error: str):
        """Report error"""
        console.print(f"[bold red]Error:[/bold red] {error}")
    
    def report_progress(self, current: int, total: int, message: str = ""):
        """Report progress"""
        percentage = (current / total) * 100 if total > 0 else 0
        console.print(f"[cyan]Progress:[/cyan] {current}/{total} ({percentage:.1f}%) {message}")
    
    def generate_summary(self) -> Dict[str, Any]:
        """Generate summary of all results"""
        if not self.results:
            return {}
        
        successful = [r for r in self.results if r['result']]
        failed = [r for r in self.results if not r['result']]
        
        total_duration = sum(r['duration'] for r in self.results)
        
        return {
            'total_hashes': len(self.results),
            'successful': len(successful),
            'failed': len(failed),
            'success_rate': len(successful) / len(self.results) * 100,
            'total_duration': total_duration,
            'average_duration': total_duration / len(self.results),
            'results': self.results
        }
    
    def export_results(self, output_file: str, format: str = 'json'):
        """Export results to file"""
        try:
            if format == 'json':
                with open(output_file, 'w') as f:
                    json.dump(self.generate_summary(), f, indent=2)
            elif format == 'csv':
                with open(output_file, 'w', newline='') as f:
                    writer = csv.writer(f)
                    writer.writerow(['Hash', 'Type', 'Result', 'Duration', 'Timestamp'])
                    for result in self.results:
                        writer.writerow([
                            result['hash'],
                            result['type'],
                            result['result'] or 'NOT_FOUND',
                            result['duration'],
                            result['timestamp']
                        ])
            else:
                raise ValueError(f"Unsupported format: {format}")
            
            console.print(f"[green]✓[/green] Results exported to {output_file}")
            
        except Exception as e:
            console.print(f"[red]✗[/red] Error exporting results: {e}")
    
    def display_summary_table(self):
        """Display summary table of results"""
        if not self.results:
            console.print("[yellow]No results to display[/yellow]")
            return
        
        table = Table(title="Hash Cracking Summary")
        table.add_column("Hash", style="cyan", max_width=30)
        table.add_column("Type", style="yellow")
        table.add_column("Result", style="green")
        table.add_column("Duration", style="blue")
        table.add_column("Status", style="bold")
        
        for result in self.results:
            status = "✓ SUCCESS" if result['result'] else "✗ FAILED"
            status_style = "green" if result['result'] else "red"
            
            table.add_row(
                result['hash'][:30] + "..." if len(result['hash']) > 30 else result['hash'],
                result['type'],
                result['result'] or "NOT_FOUND",
                f"{result['duration']:.2f}s",
                f"[{status_style}]{status}[/{status_style}]"
            )
        
        console.print(table)
