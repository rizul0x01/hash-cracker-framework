"""
Performance monitoring utilities
"""

import time
import threading
from typing import Optional, Dict, Any

class PerformanceMetrics:
    """Performance metrics collection and analysis"""
    
    def __init__(self):
        self.start_time: Optional[float] = None
        self.end_time: Optional[float] = None
        self.attempts: int = 0
        self.lock = threading.Lock()
        
    def start(self):
        """Start performance monitoring"""
        with self.lock:
            self.start_time = time.time()
            self.attempts = 0
    
    def stop(self):
        """Stop performance monitoring"""
        with self.lock:
            self.end_time = time.time()
    
    def increment_attempts(self, count: int = 1):
        """Increment attempt counter"""
        with self.lock:
            self.attempts += count
    
    def get_duration(self) -> float:
        """Get duration in seconds"""
        with self.lock:
            if self.start_time is None:
                return 0.0
            end = self.end_time or time.time()
            return end - self.start_time
    
    def get_attempts(self) -> int:
        """Get total attempts"""
        with self.lock:
            return self.attempts
    
    def get_rate(self) -> float:
        """Get attempts per second"""
        duration = self.get_duration()
        if duration > 0:
            return self.attempts / duration
        return 0.0
    
    def get_stats(self) -> Dict[str, Any]:
        """Get comprehensive statistics"""
        with self.lock:
            duration = self.get_duration()
            rate = self.get_rate()
            
            return {
                'duration': duration,
                'attempts': self.attempts,
                'rate': rate,
                'start_time': self.start_time,
                'end_time': self.end_time,
                'is_running': self.start_time is not None and self.end_time is None
            }
    
    def reset(self):
        """Reset all metrics"""
        with self.lock:
            self.start_time = None
            self.end_time = None
            self.attempts = 0

class ResourceMonitor:
    """Monitor system resources during cracking"""
    
    def __init__(self):
        self.cpu_usage = []
        self.memory_usage = []
        self.monitoring = False
        self.monitor_thread = None
    
    def start_monitoring(self, interval: float = 1.0):
        """Start resource monitoring"""
        if self.monitoring:
            return
        
        self.monitoring = True
        self.monitor_thread = threading.Thread(
            target=self._monitor_resources,
            args=(interval,),
            daemon=True
        )
        self.monitor_thread.start()
    
    def stop_monitoring(self):
        """Stop resource monitoring"""
        self.monitoring = False
        if self.monitor_thread:
            self.monitor_thread.join()
    
    def _monitor_resources(self, interval: float):
        """Monitor system resources"""
        try:
            import psutil
            
            while self.monitoring:
                cpu = psutil.cpu_percent(interval=0.1)
                memory = psutil.virtual_memory().percent
                
                self.cpu_usage.append(cpu)
                self.memory_usage.append(memory)
                
                time.sleep(interval)
                
        except ImportError:
            # psutil not available
            pass
    
    def get_stats(self) -> Dict[str, Any]:
        """Get resource statistics"""
        if not self.cpu_usage or not self.memory_usage:
            return {}
        
        return {
            'cpu': {
                'avg': sum(self.cpu_usage) / len(self.cpu_usage),
                'max': max(self.cpu_usage),
                'min': min(self.cpu_usage)
            },
            'memory': {
                'avg': sum(self.memory_usage) / len(self.memory_usage),
                'max': max(self.memory_usage),
                'min': min(self.memory_usage)
            }
        }
