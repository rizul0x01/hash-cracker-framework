"""
PBKDF2-SHA256 hash cracking implementation
"""

import hashlib
import base64
from typing import List, Optional, Callable
from ..utils.performance import PerformanceMetrics

def crack_pbkdf2_sha256(hash_str: str, salt: bytes, iterations: int, 
                       wordlist: List[str], 
                       progress_callback: Optional[Callable] = None) -> Optional[str]:
    """
    Crack PBKDF2-SHA256 hash using dictionary attack
    
    Args:
        hash_str: PBKDF2 hash string
        salt: Salt bytes
        iterations: Number of iterations
        wordlist: List of passwords to try
        progress_callback: Optional callback for progress updates
        
    Returns:
        Cracked password or None if not found
    """
    metrics = PerformanceMetrics()
    metrics.start()
    
    try:
        # Parse hash if it's in standard format
        if hash_str.startswith('$pbkdf2-sha256$'):
            parts = hash_str.split('$')
            if len(parts) >= 5:
                iterations = int(parts[2])
                salt = base64.b64decode(parts[3])
                expected_hash = base64.b64decode(parts[4])
        else:
            # Assume raw hash
            expected_hash = bytes.fromhex(hash_str) if len(hash_str) % 2 == 0 else hash_str.encode()
        
        for word in wordlist:
            metrics.increment_attempts()
            
            if progress_callback:
                progress_callback()
            
            try:
                derived = hashlib.pbkdf2_hmac('sha256', word.encode('utf-8'), salt, iterations)
                if derived == expected_hash:
                    metrics.stop()
                    return word
            except Exception:
                continue
        
        metrics.stop()
        return None
        
    except Exception as e:
        metrics.stop()
        return None

def verify_pbkdf2_sha256(password: str, hash_str: str, salt: bytes, iterations: int) -> bool:
    """
    Verify password against PBKDF2-SHA256 hash
    
    Args:
        password: Password to verify
        hash_str: PBKDF2 hash string
        salt: Salt bytes
        iterations: Number of iterations
        
    Returns:
        True if password matches hash
    """
    try:
        derived = hashlib.pbkdf2_hmac('sha256', password.encode('utf-8'), salt, iterations)
        expected = bytes.fromhex(hash_str) if len(hash_str) % 2 == 0 else hash_str.encode()
        return derived == expected
    except Exception:
        return False
