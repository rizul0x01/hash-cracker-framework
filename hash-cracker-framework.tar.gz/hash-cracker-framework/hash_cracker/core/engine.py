"""
Main cracking engine that orchestrates the hash cracking process
"""

import os
import json
import time
from typing import Optional, Dict, Any
from rich.console import Console
from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn, TimeElapsedColumn
from rich.panel import Panel
from rich.table import Table

from hash_cracker.core.detector import HashDetector
from hash_cracker.core.dispatcher import CrackingDispatcher
from hash_cracker.core.reporter import Reporter
from hash_cracker.utils.errors import HashCrackerError, UnsupportedHashTypeError
from hash_cracker.utils.performance import PerformanceMetrics

console = Console()

class CrackEngine:
    """Main hash cracking engine"""
    
    def __init__(self):
        self.detector = HashDetector()
        self.dispatcher = CrackingDispatcher()
        self.reporter = Reporter()
        self.metrics = PerformanceMetrics()
        
    def run(self, hash_value: str, wordlist_path: Optional[str] = None, 
            attack_options: Optional[Dict[str, Any]] = None):
        """
        Main method to run the hash cracking process
        
        Args:
            hash_value: The hash to crack
            wordlist_path: Path to wordlist file
            attack_options: Dictionary of attack options
        """
        if not attack_options:
            attack_options = {}
            
        try:
            # Start performance monitoring
            self.metrics.start()
            
            # Step 1: Hash Detection
            self._report_step("Hash Detection", "Analyzing hash format...")
            hash_info = self.detector.get_hash_info(hash_value)
            detected_type = hash_info["type"]
            
            if not detected_type:
                raise UnsupportedHashTypeError("Could not detect hash type")
            
            self._display_hash_info(hash_info)
            
            # Step 2: Load wordlist if provided
            # The wordlist loading logic is now moved to the dispatcher
            
            # Step 3: Start cracking process
            self._report_step("Hash Cracking", f"Starting {detected_type} cracking process...")
            
            with Progress(
                SpinnerColumn(),
                TextColumn("[progress.description]{task.description}"),
                BarColumn(),
                TextColumn("[progress.percentage]{task.percentage:>3.0f}%"),
                TimeElapsedColumn(),
                console=console,
                transient=True
            ) as progress:
                
                task = progress.add_task("Cracking hash...", total=None)
                
                # Dispatch to appropriate cracker
                result = self.dispatcher.dispatch(
                    hash_value, 
                    wordlist_path, 
                    attack_options,
                    progress_callback=lambda: progress.update(task, advance=1)
                )
                
                progress.update(task, completed=True)
            
            # Step 4: Report results
            self.metrics.stop()
            self._report_results(hash_value, detected_type, result, hash_info)
            
            # Step 5: Save results if requested
            if attack_options.get("output"):
                self._save_results(hash_value, detected_type, result, attack_options)
                
        except KeyboardInterrupt:
            console.print("\n[red]✗[/red] Process interrupted by user")
            raise
        except Exception as e:
            console.print(f"\n[red]✗[/red] Error: {str(e)}")
            raise
    
    def _report_step(self, title: str, message: str):
        """Report a step in the cracking process"""
        console.print(f"\n[bold cyan]{title}[/bold cyan]")
        console.print(f"[yellow]→[/yellow] {message}")
    
    def _display_hash_info(self, hash_info: Dict):
        """Display hash information in a formatted table"""
        table = Table(title="Hash Analysis Results")
        table.add_column("Property", style="cyan")
        table.add_column("Value", style="yellow")
        
        table.add_row("Hash Type", hash_info["type"] or "Unknown")
        table.add_row("Length", str(hash_info["length"]))
        table.add_row("Character Set", hash_info["charset"])
        if "description" in hash_info:
            table.add_row("Description", hash_info["description"])
        
        console.print(table)
    
    def _load_wordlist(self, wordlist_path: str) -> list:
        """Load wordlist from file"""
        try:
            with open(wordlist_path, "r", encoding="utf-8", errors="ignore") as f:
                return [line.strip() for line in f if line.strip()]
        except Exception as e:
            raise HashCrackerError(f"Error loading wordlist: {e}")
    
    def _report_results(self, hash_value: str, hash_type: str, result: Optional[str], hash_info: Dict):
        """Report cracking results"""
        console.print("\n" + "="*60)
        
        if result:
            # Success
            panel = Panel(
                f"[bold green]PASSWORD FOUND![/bold green]\n\n"
                f"Hash: {hash_value}\n"
                f"Type: {hash_type}\n"
                f"Password: [bold red]{result}[/bold red]\n"
                f"Time: {self.metrics.get_duration():.2f} seconds\n"
                f"Attempts: {self.metrics.get_attempts()}",
                title="[bold green]SUCCESS[/bold green]",
                border_style="green"
            )
        else:
            # Failure
            panel = Panel(
                f"[bold red]PASSWORD NOT FOUND[/bold red]\n\n"
                f"Hash: {hash_value}\n"
                f"Type: {hash_type}\n"
                f"Time: {self.metrics.get_duration():.2f} seconds\n"
                f"Attempts: {self.metrics.get_attempts()}",
                title="[bold red]FAILED[/bold red]",
                border_style="red"
            )
        
        console.print(panel)
        
        # Performance metrics
        if self.metrics.get_duration() > 0:
            rate = self.metrics.get_attempts() / self.metrics.get_duration()
            console.print(f"\n[cyan]Performance:[/cyan] {rate:.2f} attempts/second")
    
    def _save_results(self, hash_value: str, hash_type: str, result: Optional[str], 
                     attack_options: Dict[str, Any]):
        """Save results to file"""
        output_file = attack_options["output"]
        output_format = attack_options.get("format", "txt")
        
        results_data = {
            "hash": hash_value,
            "type": hash_type,
            "result": result,
            "found": result is not None,
            "timestamp": time.time(),
            "duration": self.metrics.get_duration(),
            "attempts": self.metrics.get_attempts(),
            "attack_options": attack_options
        }
        
        try:
            if output_format == "json":
                with open(output_file, "w") as f:
                    json.dump(results_data, f, indent=2)
            elif output_format == "csv":
                import csv
                with open(output_file, "w", newline="") as f:
                    writer = csv.writer(f)
                    writer.writerow(["Hash", "Type", "Result", "Found", "Duration", "Attempts"])
                    writer.writerow([
                        hash_value, hash_type, result or "", 
                        result is not None, self.metrics.get_duration(), 
                        self.metrics.get_attempts()
                    ])
            else:  # txt format
                with open(output_file, "w") as f:
                    f.write(f"Hash Cracking Results\n")
                    f.write(f"===================\n\n")
                    f.write(f"Hash: {hash_value}\n")
                    f.write(f"Type: {hash_type}\n")
                    f.write(f"Result: {result or 'NOT FOUND'}\n")
                    f.write(f"Duration: {self.metrics.get_duration():.2f} seconds\n")
                    f.write(f"Attempts: {self.metrics.get_attempts()}\n")
            
            console.print(f"[green]✓[/green] Results saved to {output_file}")
            
        except Exception as e:
            console.print(f"[red]✗[/red] Error saving results: {e}")


