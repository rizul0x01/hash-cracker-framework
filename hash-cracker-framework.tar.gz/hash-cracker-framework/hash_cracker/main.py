import argparse
from hash_cracker.core.engine import CrackEngine
from hash_cracker.cli import setup_cli_parser
from hash_cracker.core.detector import HashDetector
import re

def print_header():
    GREEN = "\033[92m"
    RESET = "\033[0m"
    header = f"""{GREEN}
+-----------------------------------------------------------------------------------+
|    |A|D|V|A|N|C|E|D| |H|A|S|H| |C|R|A|C|K|I|N|G| |F|R|A|M|E|W|R|O|R|K| |v1.0|     |
+-----------------------------------------------------------------------------------+
|                                [ by rizul0x01 ]                                   |
+-----------------------------------------------------------------------------------+
{RESET}"""
    print(header)

def main():
    print_header()
    parser = setup_cli_parser()
    args = parser.parse_args()

    hash_value = None
    if args.hash_file:
        with open(args.hash_file, 'r') as f:
            hash_value = f.read().strip()
    elif args.hash:
        hash_value = args.hash
    else:
        hash_value = input("Enter hash value: ").strip()

    wordlist_path = None
    if args.wordlist:
        wordlist_path = args.wordlist
    else:
        wordlist_path = input("Enter path to wordlist (leave empty for default): ").strip()
        if not wordlist_path:
            wordlist_path = "hash_cracker/wordlist.txt"
    YELLOW = "\033[93m"
    RESET = "\033[0m"
    print(f"\n{YELLOW}Tip:{RESET} Generate a custom wordlist here → https://github.com/rizul0x01/password-wordlist-generator")
    if hash_value:
        engine = CrackEngine()
        engine.run(hash_value, wordlist_path)
    else:
        parser.print_help()

if __name__ == "__main__":
    main()


