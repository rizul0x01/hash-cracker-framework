"""
Wordlist processing utilities
"""

import os
import gzip
import urllib.request
from typing import List, Iterator, Optional
from pathlib import Path

class WordlistProcessor:
    """Process and manage wordlists"""
    
    def __init__(self):
        self.common_wordlists = {
            'rockyou': 'https://github.com/brannondorsey/naive-hashcat/releases/download/data/rockyou.txt',
            'common': 'https://raw.githubusercontent.com/danielmiessler/SecLists/master/Passwords/Common-Credentials/10-million-password-list-top-1000.txt',
            'top1000': 'https://raw.githubusercontent.com/danielmiessler/SecLists/master/Passwords/Common-Credentials/10-million-password-list-top-1000.txt'
        }
    
    def load_wordlist(self, filepath: str) -> List[str]:
        """
        Load wordlist from file
        
        Args:
            filepath: Path to wordlist file
            
        Returns:
            List of words
        """
        words = []
        
        try:
            if filepath.endswith('.gz'):
                with gzip.open(filepath, 'rt', encoding='utf-8', errors='ignore') as f:
                    words = [line.strip() for line in f if line.strip()]
            else:
                with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
                    words = [line.strip() for line in f if line.strip()]
        except Exception as e:
            raise Exception(f"Error loading wordlist: {e}")
        
        return words
    
    def create_wordlist_iterator(self, filepath: str) -> Iterator[str]:
        """
        Create iterator for large wordlists
        
        Args:
            filepath: Path to wordlist file
            
        Yields:
            Individual words from wordlist
        """
        try:
            if filepath.endswith('.gz'):
                with gzip.open(filepath, 'rt', encoding='utf-8', errors='ignore') as f:
                    for line in f:
                        word = line.strip()
                        if word:
                            yield word
            else:
                with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
                    for line in f:
                        word = line.strip()
                        if word:
                            yield word
        except Exception as e:
            raise Exception(f"Error reading wordlist: {e}")
    
    def download_wordlist(self, name: str, output_dir: str = ".") -> str:
        """
        Download common wordlist
        
        Args:
            name: Name of wordlist to download
            output_dir: Directory to save wordlist
            
        Returns:
            Path to downloaded wordlist
        """
        if name not in self.common_wordlists:
            raise ValueError(f"Unknown wordlist: {name}")
        
        url = self.common_wordlists[name]
        filename = f"{name}.txt"
        filepath = os.path.join(output_dir, filename)
        
        if os.path.exists(filepath):
            return filepath
        
        try:
            print(f"Downloading {name} wordlist...")
            urllib.request.urlretrieve(url, filepath)
            print(f"Downloaded to {filepath}")
            return filepath
        except Exception as e:
            raise Exception(f"Error downloading wordlist: {e}")
    
    def merge_wordlists(self, filepaths: List[str], output_path: str, 
                       remove_duplicates: bool = True) -> int:
        """
        Merge multiple wordlists
        
        Args:
            filepaths: List of wordlist file paths
            output_path: Output file path
            remove_duplicates: Whether to remove duplicates
            
        Returns:
            Number of words in merged wordlist
        """
        words = set() if remove_duplicates else []
        
        for filepath in filepaths:
            try:
                current_words = self.load_wordlist(filepath)
                if remove_duplicates:
                    words.update(current_words)
                else:
                    words.extend(current_words)
            except Exception as e:
                print(f"Error loading {filepath}: {e}")
                continue
        
        # Write merged wordlist
        with open(output_path, 'w', encoding='utf-8') as f:
            if remove_duplicates:
                for word in sorted(words):
                    f.write(word + '\n')
            else:
                for word in words:
                    f.write(word + '\n')
        
        return len(words)
    
    def filter_wordlist(self, input_path: str, output_path: str, 
                       min_length: int = 1, max_length: int = 100,
                       allowed_chars: Optional[str] = None) -> int:
        """
        Filter wordlist based on criteria
        
        Args:
            input_path: Input wordlist path
            output_path: Output wordlist path
            min_length: Minimum word length
            max_length: Maximum word length
            allowed_chars: Allowed characters (None for no restriction)
            
        Returns:
            Number of words in filtered wordlist
        """
        count = 0
        
        with open(output_path, 'w', encoding='utf-8') as output_file:
            for word in self.create_wordlist_iterator(input_path):
                if len(word) < min_length or len(word) > max_length:
                    continue
                
                if allowed_chars and not all(c in allowed_chars for c in word):
                    continue
                
                output_file.write(word + '\n')
                count += 1
        
        return count
    
    def get_wordlist_stats(self, filepath: str) -> dict:
        """
        Get statistics about wordlist
        
        Args:
            filepath: Path to wordlist file
            
        Returns:
            Dictionary with statistics
        """
        stats = {
            'total_words': 0,
            'unique_words': 0,
            'min_length': float('inf'),
            'max_length': 0,
            'avg_length': 0,
            'charset': set()
        }
        
        words = set()
        total_length = 0
        
        for word in self.create_wordlist_iterator(filepath):
            stats['total_words'] += 1
            words.add(word)
            
            length = len(word)
            stats['min_length'] = min(stats['min_length'], length)
            stats['max_length'] = max(stats['max_length'], length)
            total_length += length
            
            stats['charset'].update(word)
        
        stats['unique_words'] = len(words)
        stats['avg_length'] = total_length / stats['total_words'] if stats['total_words'] > 0 else 0
        stats['charset'] = ''.join(sorted(stats['charset']))
        
        if stats['min_length'] == float('inf'):
            stats['min_length'] = 0
        
        return stats
