"""
Dictionary attack implementation
"""

from typing import Callable, Optional, List
from ..utils.performance import PerformanceMetrics
from ..utils.rules import apply_rules

class DictionaryCracker:
    """Dictionary-based password cracker"""
    
    def __init__(self, wordlist: List[str], verify_func: Callable[[str, str], bool]):
        """
        Initialize dictionary cracker
        
        Args:
            wordlist: List of words to try
            verify_func: Function to verify password against hash
        """
        self.wordlist = wordlist
        self.verify_func = verify_func
        self.metrics = PerformanceMetrics()

    def crack(self, target_hash: str, progress_callback: Optional[Callable] = None) -> Optional[str]:
        """
        Crack hash using dictionary attack
        
        Args:
            target_hash: Hash to crack
            progress_callback: Optional callback for progress updates
            
        Returns:
            Cracked password or None if not found
        """
        self.metrics.start()
        
        try:
            for word in self.wordlist:
                self.metrics.increment_attempts()
                
                if progress_callback:
                    progress_callback()
                
                # Try original word
                try:
                    if self.verify_func(word, target_hash):
                        self.metrics.stop()
                        return word
                except Exception:
                    pass
                
                # Try mangled versions
                mangled_words = apply_rules(word)
                for mangled_word in mangled_words:
                    self.metrics.increment_attempts()
                    
                    if progress_callback:
                        progress_callback()
                    
                    try:
                        if self.verify_func(mangled_word, target_hash):
                            self.metrics.stop()
                            return mangled_word
                    except Exception:
                        continue
            
            self.metrics.stop()
            return None
            
        except KeyboardInterrupt:
            self.metrics.stop()
            raise
        except Exception as e:
            self.metrics.stop()
            return None

    def get_metrics(self) -> PerformanceMetrics:
        """Get performance metrics"""
        return self.metrics
