"""
Password mangling rules for dictionary attacks
"""

from typing import List, Iterator

def apply_rules(word: str) -> List[str]:
    """
    Apply password mangling rules to a word
    
    Args:
        word: Base word to mangle
        
    Returns:
        List of mangled words
    """
    mangled = []
    
    # Original word
    mangled.append(word)
    
    # Case variations
    mangled.append(word.lower())
    mangled.append(word.upper())
    mangled.append(word.capitalize())
    
    # Reverse
    mangled.append(word[::-1])
    
    # Leet speak substitutions
    mangled.extend(apply_leet_speak(word))
    
    # Append common numbers
    for num in ['1', '123', '2023', '2024', '2025', '0', '01', '99']:
        mangled.append(word + num)
        mangled.append(num + word)
    
    # Append common symbols
    for symbol in ['!', '@', '#', '$', '%', '^', '&', '*']:
        mangled.append(word + symbol)
        mangled.append(symbol + word)
    
    # Common suffixes
    suffixes = ['ing', 'ed', 'er', 'ly', 's', 'es']
    for suffix in suffixes:
        mangled.append(word + suffix)
    
    # Common prefixes
    prefixes = ['un', 're', 'pre', 'over', 'under']
    for prefix in prefixes:
        mangled.append(prefix + word)
    
    # Duplicate characters
    mangled.append(word + word)
    
    # Remove duplicates and return
    return list(set(mangled))

def apply_leet_speak(word: str) -> List[str]:
    """
    Apply leet speak transformations
    
    Args:
        word: Word to transform
        
    Returns:
        List of leet speak variations
    """
    leet_map = {
        'a': ['@', '4'],
        'e': ['3'],
        'i': ['1', '!'],
        'o': ['0'],
        's': ['5', '$'],
        't': ['7'],
        'l': ['1'],
        'g': ['9'],
        'b': ['6'],
        'z': ['2']
    }
    
    variations = []
    
    # Single character substitutions
    for char, replacements in leet_map.items():
        for replacement in replacements:
            if char in word.lower():
                # Replace first occurrence
                new_word = word.lower().replace(char, replacement, 1)
                variations.append(new_word)
                
                # Replace all occurrences
                new_word = word.lower().replace(char, replacement)
                variations.append(new_word)
    
    # Multiple substitutions
    word_lower = word.lower()
    if 'a' in word_lower and 'e' in word_lower:
        new_word = word_lower.replace('a', '@').replace('e', '3')
        variations.append(new_word)
    
    if 'i' in word_lower and 'o' in word_lower:
        new_word = word_lower.replace('i', '1').replace('o', '0')
        variations.append(new_word)
    
    return variations

def apply_toggle_case(word: str) -> List[str]:
    """
    Apply case toggling variations
    
    Args:
        word: Word to toggle
        
    Returns:
        List of case-toggled variations
    """
    variations = []
    
    # Toggle every other character
    toggled = ""
    for i, char in enumerate(word):
        if i % 2 == 0:
            toggled += char.upper()
        else:
            toggled += char.lower()
    variations.append(toggled)
    
    # Reverse toggle
    toggled = ""
    for i, char in enumerate(word):
        if i % 2 == 0:
            toggled += char.lower()
        else:
            toggled += char.upper()
    variations.append(toggled)
    
    return variations

def apply_keyboard_shifts(word: str) -> List[str]:
    """
    Apply keyboard shift variations
    
    Args:
        word: Word to shift
        
    Returns:
        List of keyboard-shifted variations
    """
    shift_map = {
        'q': 'w', 'w': 'e', 'e': 'r', 'r': 't', 't': 'y', 'y': 'u',
        'u': 'i', 'i': 'o', 'o': 'p', 'p': 'q',
        'a': 's', 's': 'd', 'd': 'f', 'f': 'g', 'g': 'h', 'h': 'j',
        'j': 'k', 'k': 'l', 'l': 'a',
        'z': 'x', 'x': 'c', 'c': 'v', 'v': 'b', 'b': 'n', 'n': 'm',
        'm': 'z'
    }
    
    variations = []
    
    # Right shift
    shifted = ""
    for char in word.lower():
        shifted += shift_map.get(char, char)
    variations.append(shifted)
    
    # Left shift (reverse mapping)
    reverse_map = {v: k for k, v in shift_map.items()}
    shifted = ""
    for char in word.lower():
        shifted += reverse_map.get(char, char)
    variations.append(shifted)
    
    return variations
