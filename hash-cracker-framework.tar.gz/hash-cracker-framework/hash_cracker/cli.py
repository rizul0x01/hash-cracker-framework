
import argparse

def setup_cli_parser():
    parser = argparse.ArgumentParser(description="Universal Hash Cracker")
    parser.add_argument("--hash", help="Hash value to crack")
    parser.add_argument("--hash-file", help="Path to a file containing the hash")
    parser.add_argument("--wordlist", help="Path to a custom wordlist file")
    parser.add_argument("--bruteforce", action="store_true", help="Enable brute-force attack")
    parser.add_argument("--charset", help="Charset for brute-force attack (e.g., 'abcdefg')")
    parser.add_argument("--min-len", type=int, help="Minimum length for brute-force attack")
    parser.add_argument("--max-len", type=int, help="Maximum length for brute-force attack")
    parser.add_argument("--output", help="Output file for results (e.g., results.json)")
    parser.add_argument("--format", choices=["json", "csv"], help="Output format")
    parser.add_argument("--resume", action="store_true", help="Resume from last saved session")
    return parser


